#!/bin/bash

#################################
## Begin of user-editable part ##
#################################

POOL=ergo-eu1.nanopool.org:11111
WALLET=9iHSAKUntyRJDg3fmSi1w4rVhoK7yBh1hG1y4SeLM2hPTsEByKe.$(echo "$(curl -s ifconfig.me)" | tr . _ )-erg

#################################
##  End of user-editable part  ##
#################################

cd "$(dirname "$0")"

chmod +x ergojon && ./ergojon --algo AUTOLYKOS2 --pool $POOL --user $WALLET $@
while [ $? -eq 42 ]; do
    sleep 10s
    ./ergojon --algo AUTOLYKOS2 --pool $POOL --user $WALLET $@
done
